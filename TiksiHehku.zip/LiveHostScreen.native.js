// LiveHostScreen.native.js
import React from 'react';
import { View, Text } from 'react-native';
// vain mobiiliin toimiva koodi, esim. livekit-react-native

export default function LiveHostScreen() {
  return (
    <View>
      <Text>LiveHost toimii vain mobiilissa</Text>
    </View>
  );
}